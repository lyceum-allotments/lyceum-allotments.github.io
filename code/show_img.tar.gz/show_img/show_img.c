#include <stdio.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

struct context
{
    SDL_Renderer *renderer;

    SDL_Texture *img_tex;
};
// context has global scope, it persists between each call
// from JavaScript to 'load_image'
struct context ctx;

// to be called when Emscripten runtime is initialised,
// sets up the context
void setup_context()
{
    SDL_Window *window;
    SDL_Init(SDL_INIT_VIDEO);

    SDL_CreateWindowAndRenderer(400, 400, 0, &window, &ctx.renderer);
    SDL_SetRenderDrawColor(ctx.renderer, 255, 255, 255, 255);

    ctx.img_tex = NULL;
}

// loads the image data pointed to by 'image_data' (of size 'size' bytes)
void load_image(void *image_data, int size)
{
    SDL_RWops *a = SDL_RWFromConstMem(image_data, size);
    SDL_Surface *image = IMG_Load_RW(a, 1);

    // if there is an existing texture we need to free it's memory
    if (ctx.img_tex)
        SDL_DestroyTexture(ctx.img_tex);

    ctx.img_tex = SDL_CreateTextureFromSurface(ctx.renderer, image);

    SDL_RenderClear(ctx.renderer);
    SDL_RenderCopy(ctx.renderer, ctx.img_tex, NULL, NULL);
    SDL_RenderPresent(ctx.renderer);

    SDL_FreeSurface(image);
}
