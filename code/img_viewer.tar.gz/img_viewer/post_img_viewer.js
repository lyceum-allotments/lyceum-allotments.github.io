(function(){
    ImgViewer = function(image, canvas_element) {
        // Uint8Array of bytes of image will be stored here
        var image_bytes = 0;

        // Emscripten exported function for loading an image into
        // the viewer will be stored here
        var loadImage = 0;

        var loadImageBytes = function(image) {
            // create a temporary canvas element for this task
            var canvas = document.createElement('canvas');

            // set it to have same size of underlying image
            canvas.width = image.naturalWidth;
            canvas.height = image.naturalHeight;

            // load the image in the canvas
            canvas.getContext('2d').drawImage(image, 0, 0);

            // convert the image to a data URI.
            // A data URI has a prefix describing the type of data the string 
            // following contains, we don't need this so just replace it with nothing
            var string_data = canvas.toDataURL('image/png').replace(/^data:image\/(png|jpg);base64,/, '');

            // change the data URI from a base64 to an ASCII encoded string
            var decoded_data = atob(string_data);

            // make an unsigned 8 bit int typed array large enough to hold image data
            var array_data = new Uint8Array(decoded_data.length);

            // convert ASCII string to unsigned 8 bit int array
            for (var i = 0; i < decoded_data.length; i++)
            {
                array_data[i] = decoded_data.charCodeAt(i);
            }

            image_bytes = array_data;
        };

        var options = {
          preRun: [],
          postRun: [],
          print: function(text){console.log(text)},
          printErr: function(text) {console.error(text)},
          canvas: (function() {
              return canvas_element;
          })(),
          onRuntimeInitialized: function() {
              this.ccall('setup_context', null);
              loadImage = this.cwrap('load_image', null, ['array', 'number']);
              if (image_bytes) // if an image has already been loaded by the time
                               // this call back is called, load the image bytes
                               // into the viewer
              {
                loadImage(image_bytes, image_bytes.length);
              }
          },
        };

        // load the initial image
        loadImageBytes(image);

        // create an image viewer with the options
        EmImgViewer(options);

        return {
            'changeImage' : function(image) { // method to change image to HTTPImageElement `image`
                loadImageBytes(image);
                if(loadImage)
                    loadImage(image_bytes, image_bytes.length);
            }
        };
    };
})();
