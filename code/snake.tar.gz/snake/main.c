#include "engine.h"
#include "apple_actor.h"
#include "background_actor.h"
#include <stdio.h>

int main()
{
    engine_init(
             800,
             600);

    engine_start();
}
