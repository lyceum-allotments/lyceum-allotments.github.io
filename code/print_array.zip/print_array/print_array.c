#include <stdio.h>
#include <stdint.h>

void print_array(uint8_t *a)
{
    printf("array is [%u, %u, %u, %u]\n", a[0], a[1], a[2], a[3]);
}
